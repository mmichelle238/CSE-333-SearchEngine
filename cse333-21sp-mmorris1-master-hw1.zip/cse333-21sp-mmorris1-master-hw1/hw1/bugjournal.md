# Bug 1

## A) How is your program acting differently than you expect it to?
- I'm not passing the test for push/pop and append/slice with the linked list
- I can also see with valgrind the assertion that failed was specifically for push
and slice, and since the code is similar between both of them, I believe the error
is going to be the same

## B) Brainstorm a few possible causes of the bug
- Based on the assertion, it looks like the payload is incorrect,
which is why I think there is an error with the pointers

## C) How you fixed the bug and why the fix was necessary
- I needed to include an * before the payload pointer so that the value that
the pointer points at is the correct value. This had to be fixed because if you just
set the pointer to a value, it interprets it as a location and not the actual value
it is pointing at


# Bug 2

## A) How is your program acting differently than you expect it to?
- I am getting a segmentation fault with the linked list iterator, and using the valgrind
we can see that the error occurs after a remove call, which makes me think the
remove method has the error

## B) Brainstorm a few possible causes of the bug
- I used the pop and slice methods from the linked list that was used before,
but I think creating those sections from scratch could fix it

## C) How you fixed the bug and why the fix was necessary
- I realized that I was trying to free the payload without using the function
to free the payload and this fix was necessary since otherwise you can't properly
free the payload which can lead to memory leaks


# Bug 3

## A) How is your program acting differently than you expect it to?
- In the hashtable insert method I was having trouble changing the payload if the
key already existed in the linked list

## B) Brainstorm a few possible causes of the bug
- maybe I'm not use the linked list iterator properly?
- maybe i shouldn't be using a linked list iterator at all
- maybe i'm not casting the key value pair correctly

## C) How you fixed the bug and why the fix was necessary
- I realized that I first of all didn't include the interface
at the top of my code, so I had to do that first
- I then realized that I can only use the methods from interface, and
can't access any values in the node since those are hidden
- the only other way to "switch" the values would be to remove the old
key and value and then insert in the new one


# Bug 4

## A) How is your program acting differently than you expect it to?
- the final old value is not equal to the new value

## B) Brainstorm a few possible causes of the bug
- initially i thought the error was with the old value, however, I then
wondered if the error was in the new node that was pushed onto the linked list
since the old value logically made sense

## C) How you fixed the bug and why the fix was necessary
- After using gdb, I saw that the newly added node disappeared since it wasn't
added into the heap (using malloc). I originally assumed that this was done already,
but since a pointer to the new key and value wasn't passed through, I realized i had
to actually malloc a pointer to the new hash node and set the values equal to the
new values that are passed through. This was necessary to have access to the values
in the future.


# Bug 5

## A) How is your program acting differently than you expect it to?
- my program fails a verify 333 test when resize is called in my insert method

## B) Brainstorm a few possible causes of the bug
- the error is actually in the iterator since resize calls and uses
the iterator
- my isValid and get method make logical sense, so the error has to be in next

## C) How you fixed the bug and why the fix was necessary
- I went to office hours for some help and with the use of gdb we realized for sure
that the error was in the next method, and that the error was because the statement
that makes the bucket_it NULL can only be reached if there are multiple buckets left
to check at the end and is not reached if we have iterated through the last bucket and
there are no buckets left to move to
